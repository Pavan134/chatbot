from django.shortcuts import render, redirect
from chat.models import Room, Message
from django.http import HttpResponse, JsonResponse
from hashlib import md5
from Cryptodome import Random
from Cryptodome.Cipher import AES
import base64
from hashlib import sha256
import hashlib
from Cryptodome.Util import Padding
# Create your views here.
passphrase = "Pavan@2001".encode()
BLOCK_SIZE = 16
k= 'y6lLepZQpppdzjkeG5MhUaaaRCychpDd'.encode("utf8")
def pad(data):
    length = BLOCK_SIZE - (len(data) % BLOCK_SIZE)
    print(data)
    return data + (chr(length)*length).encode()

def unpad(data):
    return data[:-(data[-1] if type(data[-1]) == int else ord(data[-1]))]

def bytes_to_key(data, salt, output=48):
    # extended from https://gist.github.com/gsakkis/4546068
    assert len(salt) == 8, len(salt)
    data += salt
    key = md5(data).digest()
    final_key = key
    while len(final_key) < output:
        key = md5(key + data).digest()
        final_key += key
    return final_key[:output]
def home(request):
    return render(request, 'home.html')

def room(request, room):
    username = request.GET.get('username')
    room_details = Room.objects.get(name=room)
    return render(request, 'room.html', {
        'username': username,
        'room': room,
        'room_details': room_details
    })

def checkview(request):
    room = request.POST['room_name']
    username = request.POST['username']

    if Room.objects.filter(name=room).exists():
        return redirect('/'+room+'/?username='+username)
    else:
        new_room = Room.objects.create(name=room)
        new_room.save()
        return redirect('/'+room+'/?username='+username)

def send(request):
    message = request.POST['message']
    username = request.POST['username']
    room_id = request.POST['room_id']
    iv = Random.get_random_bytes(AES.block_size)
    cipher = AES.new(k, AES.MODE_CBC, iv)
    data = Padding.pad(message.encode('utf-8'), AES.block_size, 'pkcs7')
    encrypt=base64.b64encode(iv + cipher.encrypt(data)).decode('utf-8')
    new_message = Message.objects.create(value=encrypt, user=username, room=room_id)
    new_message.save()
    return HttpResponse('Message sent successfully')

def getMessages(request, room):
    room_details = Room.objects.get(name=room)

    messages = Message.objects.filter(room=room_details.id)
    decrypt=[]
    
    for message in messages:        
        e=message.value
        enc = base64.b64decode(e)
        iv = enc[:AES.block_size]
        cipher = AES.new(k, AES.MODE_CBC, iv)
        data = Padding.unpad(cipher.decrypt(enc[AES.block_size:]), AES.block_size, 'pkcs7')
        a=[]
        a.append(message.id)
        myvar = data
        a.append(myvar.decode("utf-8"))
        a.append(message.date)
        a.append(message.user)
        a.append(message.room)
        decrypt.append(a)
        print(a)

    return JsonResponse({"messages":list(decrypt)})

from django.contrib.auth import get_user_model
from django.contrib.sites.shortcuts import get_current_site
from django.utils.encoding import force_bytes, force_text  
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from chat.token import account_activation_token
from django.template.loader import render_to_string
from django.conf import settings
from django.core.mail import BadHeaderError, send_mail, EmailMessage
from django.core import mail
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout

def login_page(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            verify_user_by_email(request, username)
        else:
            return HttpResponse("Username or Password is incorrect!")
    return render(request, 'login.html')

def logoutUser(request):
    logout(request)
    return redirect('login')

def verify_user_by_email(request, username):
    user = User.objects.get(username = username)
    current_site = get_current_site(request)
    mail_subject = "Confirm Your Account"
    message = render_to_string('confirm_email.html', {
        'user': user,  
        'domain': current_site.domain,  
        'uid':urlsafe_base64_encode(force_bytes(user.pk)),
        'token':account_activation_token.make_token(user),
    })
    current_user = User.objects.get(username = username)
    to_email = current_user.email
    email = EmailMessage(mail_subject, message, to=[to_email])
    email.send()
    return redirect('login')

def activate(request, uidb64, token):
    User = get_user_model()  
    try:  
        uid = force_text(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)  
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token): 
        user.is_active = True
        user.save()
        login(request, user)
        return render(request, 'home.html')
    else:  
        return HttpResponse('Confirmation link is invalid!')